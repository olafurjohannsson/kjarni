//! Reusable CPU-based transformer components like Attention and Layers.

pub mod attention;
pub mod layer;